function esc(s) {
  const div = document.createElement("div");
  div.textContent = s ?? "";
  return div.innerHTML;
}

// ─── Tabs ─────────────────────────────────────────────────────────────────────
document.querySelectorAll(".tab-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    const tab = btn.getAttribute("data-tab");
    document.querySelectorAll(".tab-btn").forEach(b => b.classList.toggle("active", b === btn));
    document.querySelectorAll(".tab-panel").forEach(p => {
      p.classList.toggle("active", p.id === `tab-${tab}`);
    });
  });
});

// ─── Infor column-mapping settings ───────────────────────────────────────────
const INFOR_COL_DEFAULTS = {
  assembly:     6,
  material:     9,
  materialDesc: 10,
  quantity:     11,
  uom:          12,
  seq:          14,
};

// Human labels + order for the settings grid / inspector highlighting.
const INFOR_COL_FIELDS = [
  { key: "assembly",     label: "Assembly PN" },
  { key: "material",     label: "Part Number" },
  { key: "materialDesc", label: "Description" },
  { key: "quantity",     label: "Quantity" },
  { key: "uom",          label: "UoM" },
  { key: "seq",          label: "Seq" },
];

function getInforColMap(cb) {
  chrome.storage.local.get("inforColMap", (res) => {
    cb({ ...INFOR_COL_DEFAULTS, ...((res && res.inforColMap) || {}) });
  });
}

function settingsStatus(msg, color) {
  const el = document.getElementById("settings-status");
  if (!el) return;
  el.textContent = msg || "";
  el.style.color = color || "#3fa34d";
  if (msg) setTimeout(() => { if (el.textContent === msg) el.textContent = ""; }, 2500);
}

// Render the settings grid inputs + live per-field preview from the sample row.
function renderSettings(colMap, sampleRow) {
  const grid = document.getElementById("settings-grid");
  if (!grid) return;

  grid.innerHTML = INFOR_COL_FIELDS.map(f => {
    const idx = colMap[f.key];
    const val = (sampleRow && sampleRow[idx] != null) ? String(sampleRow[idx]).trim() : "";
    const preview = sampleRow
      ? `→ ${val === "" ? "(empty)" : esc(val)}`
      : "(no sample row yet)";
    return `
      <div class="settings-field">
        <label for="set-${f.key}">${esc(f.label)}</label>
        <input type="number" id="set-${f.key}" data-key="${f.key}" value="${idx}" min="0" />
        <span class="preview" id="prev-${f.key}">${preview}</span>
      </div>`;
  }).join("");

  // Live preview + inspector highlight as the user types (before saving)
  grid.querySelectorAll("input[data-key]").forEach(inp => {
    inp.addEventListener("input", () => {
      const key = inp.getAttribute("data-key");
      const idx = parseInt(inp.value, 10);
      const val = (sampleRow && !isNaN(idx) && sampleRow[idx] != null)
        ? String(sampleRow[idx]).trim() : "";
      const prev = document.getElementById(`prev-${key}`);
      if (prev) prev.innerHTML = sampleRow
        ? `→ ${val === "" ? "(empty)" : esc(val)}` : "(no sample row yet)";
      // Re-highlight the inspector using current (unsaved) input values
      renderInspector(currentInputColMap(), sampleRow);
    });
  });
}

// Read the current (possibly unsaved) index values from the inputs.
function currentInputColMap() {
  const map = { ...INFOR_COL_DEFAULTS };
  INFOR_COL_FIELDS.forEach(f => {
    const inp = document.getElementById(`set-${f.key}`);
    if (inp) {
      const v = parseInt(inp.value, 10);
      if (!isNaN(v)) map[f.key] = v;
    }
  });
  return map;
}

// Render the raw-row inspector, highlighting cells the given colMap points at.
function renderInspector(colMap, sampleRow) {
  const box = document.getElementById("raw-row-inspector");
  if (!box) return;
  if (!sampleRow || !sampleRow.length) {
    box.innerHTML = '<div class="empty">Capture an Infor BOM to see a sample row.</div>';
    return;
  }
  // Map index -> field label(s) it's assigned to
  const idxToLabel = {};
  INFOR_COL_FIELDS.forEach(f => {
    const idx = colMap[f.key];
    if (idxToLabel[idx]) idxToLabel[idx] += ", " + f.label;
    else idxToLabel[idx] = f.label;
  });

  const cells = sampleRow.map((v, i) => {
    const mapped = idxToLabel[i];
    const valStr = String(v).trim();
    return `
      <div class="raw-cell ${mapped ? "mapped" : ""}">
        <span class="idx">${i}</span><span class="val">${valStr === "" ? "·" : esc(valStr)}</span>
        ${mapped ? `<span class="tag-label">${esc(mapped)}</span>` : ""}
      </div>`;
  }).join("");

  box.innerHTML = `<div class="raw-row">${cells}</div>`;
}

// Wire the settings tab (inputs, save, reset, inspector) once on load.
function initSettings() {
  chrome.storage.session.get("inforSampleRow", (sres) => {
    const sampleRow = (sres && sres.inforSampleRow) || null;
    getInforColMap((colMap) => {
      renderSettings(colMap, sampleRow);
      renderInspector(colMap, sampleRow);
    });
  });

  const saveBtn = document.getElementById("settings-save");
  if (saveBtn) saveBtn.addEventListener("click", () => {
    const map = currentInputColMap();
    // basic validation: all non-negative integers
    for (const f of INFOR_COL_FIELDS) {
      if (isNaN(map[f.key]) || map[f.key] < 0) {
        settingsStatus(`Invalid ${f.label} index`, "#c0392b");
        return;
      }
    }
    chrome.storage.local.set({ inforColMap: map }, () => {
      settingsStatus("Saved — re-search in Infor to apply.");
    });
  });

  const resetBtn = document.getElementById("settings-reset");
  if (resetBtn) resetBtn.addEventListener("click", () => {
    chrome.storage.local.set({ inforColMap: { ...INFOR_COL_DEFAULTS } }, () => {
      chrome.storage.session.get("inforSampleRow", (sres) => {
        const sampleRow = (sres && sres.inforSampleRow) || null;
        renderSettings({ ...INFOR_COL_DEFAULTS }, sampleRow);
        renderInspector({ ...INFOR_COL_DEFAULTS }, sampleRow);
      });
      settingsStatus("Reset to defaults.");
    });
  });
}

initSettings();

// ─── Normalization & formatting helpers ──────────────────────────────────────
function normPN(s) { return (s || "").trim().toUpperCase(); }

function toNum(s) {
  const n = parseFloat(String(s).replace(/,/g, "").trim());
  return isNaN(n) ? null : n;
}

// Only differ when numeric values actually differ (so 1.00000 === 1).
function qtyDiffers(a, b) {
  const na = toNum(a), nb = toNum(b);
  if (na === null || nb === null) return String(a).trim() !== String(b).trim();
  return Math.abs(na - nb) > 1e-6;
}

// Integer unless a real nonzero decimal exists.
function fmtQty(s) {
  const n = toNum(s);
  if (n === null) return String(s).trim();
  if (Math.abs(n - Math.round(n)) < 1e-6) return String(Math.round(n));
  return String(parseFloat(n.toFixed(5)));
}

// Mass "12.959 LB" -> "12.96" (2 decimals, no units).
function fmtMass(s) {
  const n = parseFloat(String(s).replace(/[^0-9.\-]/g, ""));
  return isNaN(n) ? "" : n.toFixed(2);
}

// BOM structure numbers ending in a trailing zero (e.g. "1.10") get an extra
// period appended ("1.10.") so Excel doesn't trim it to "1.1".
function fmtBomStruct(s) {
  const str = String(s);
  // ends with a dot-segment whose last char is 0 (e.g. .10, .20, .100)
  if (/\.\d*0$/.test(str)) return str + ".";
  return str;
}

function normDesc(s) { return (s || "").trim().replace(/\s+/g, " ").toUpperCase(); }

const UOM_GROUPS = [
  ["EA", "EACH"],
  ["FT", "FOOT", "FEET"],
  ["IN", "INCH", "INCHES"],
];
function normUom(s) {
  const u = (s || "").trim().toUpperCase();
  for (const group of UOM_GROUPS) if (group.includes(u)) return group[0];
  return u;
}

// Display form of a UoM: maps known equivalents to the canonical short form
// (e.g. "EACH" -> "EA", "FOOT" -> "FT", "INCH" -> "IN"); otherwise returns the
// trimmed original.
function normUomDisplay(s) {
  const raw = (s || "").trim();
  if (!raw) return "";
  const u = raw.toUpperCase();
  for (const group of UOM_GROUPS) if (group.includes(u)) return group[0];
  return raw;
}

// ─── Main ─────────────────────────────────────────────────────────────────────
chrome.storage.session.get(["inforStored", "onshapeStored"], (r) => {
  const infor   = r.inforStored;
  const onshape = r.onshapeStored;

  const inforBom   = (infor && infor.bom)   || [];
  const onshapeBom = (onshape && onshape.bom) || [];

  const onshapeByPN = new Map();
  onshapeBom.forEach(item => onshapeByPN.set(normPN(item.partNumber), item));
  const inforByPN = new Map();
  inforBom.forEach(item => inforByPN.set(normPN(item.partNumber), item));

  // ─── Infor table ────────────────────────────────────────────────────────────
  if (inforBom.length) {
    document.getElementById("infor-title").textContent =
      `Infor   ${infor.assembly || ""}   ${inforBom.length} items`;

    const rows = inforBom.map((item, i) => {
      const match = onshapeByPN.get(normPN(item.partNumber));
      let rowClass = "", qtyClass = "", descClass = "", uomClass = "";
      if (!match) {
        rowClass = "row-missing";
      } else {
        if (qtyDiffers(item.quantity, match.quantity)) qtyClass = "cell-orange";
        if (normDesc(item.partName) !== normDesc(match.partName)) descClass = "cell-yellow";
        if (normUom(item.uom) !== normUom(match.uom)) uomClass = "cell-brightyellow";
      }
      return `
        <tr class="${rowClass}">
          <td class="rownum">${i + 1}</td>
          <td>${esc(item.partNumber)}</td>
          <td class="${descClass}">${esc(item.partName)}</td>
          <td class="num ${qtyClass}">${esc(item.quantity)}</td>
          <td class="${uomClass}">${esc(item.uom)}</td>
          <td class="num">${esc(item.seq)}</td>
        </tr>`;
    }).join("");

    document.getElementById("infor-table").innerHTML = `
      <table>
        <thead><tr><th class="rownum">#</th><th>Part Number</th><th>Description</th><th class="num">Quantity</th><th>UoM</th><th class="num">Seq</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>`;
  }

  // ─── Onshape table ──────────────────────────────────────────────────────────
  if (onshapeBom.length) {
    document.getElementById("onshape-title").textContent =
      `Onshape   ${onshape.assembly || ""}   ${onshapeBom.length} items`;

    const rows = onshapeBom.map((item, i) => {
      const match = inforByPN.get(normPN(item.partNumber));
      let rowClass = "", qtyClass = "", descClass = "", uomClass = "";
      if (!match) {
        rowClass = "row-new";
      } else {
        if (qtyDiffers(item.quantity, match.quantity)) qtyClass = "cell-orange";
        if (normDesc(item.partName) !== normDesc(match.partName)) descClass = "cell-yellow";
        if (normUom(item.uom) !== normUom(match.uom)) uomClass = "cell-brightyellow";
      }
      return `
        <tr class="${rowClass}">
          <td class="rownum">${i + 1}</td>
          <td>${esc(item.partNumber)}</td>
          <td class="${descClass}">${esc(item.partName)}</td>
          <td class="num ${qtyClass}">${esc(item.quantity)}</td>
          <td class="${uomClass}">${esc(item.uom)}</td>
          <td class="num">${esc(item.mass)}</td>
        </tr>`;
    }).join("");

    document.getElementById("onshape-table").innerHTML = `
      <table>
        <thead><tr><th class="rownum">#</th><th>Part Number</th><th>Name</th><th class="num">Quantity</th><th>UoM</th><th class="num">Mass</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>`;
  }

  // ─── Reconciliation ──────────────────────────────────────────────────────────
  // Returns the array of reconciliation row objects (shared by display + copy).
  function computeReconRows(parentInput) {
    const parentPN = (infor && infor.assembly) || "";
    const massByPN = new Map();
    onshapeBom.forEach(it => massByPN.set(normPN(it.partNumber), it.mass));

    const reconRows = [];

    // Parent / header row — show assembly description and normalized UoM (from
    // Onshape's top-level row), but intentionally leave quantity and seq blank.
    reconRows.push({
      action: "REFERENCE", type: "ITEM",
      bomStruct: parentInput,
      partNumber: parentPN,
      description: (onshape && onshape.assemblyDesc) || "",
      quantity: "",
      uom: normUomDisplay((onshape && onshape.assemblyUom) || ""),
      mass: "",
      seq: "",
      showParentPN: false,   // parent row itself doesn't get the PN trailing col
      qtyClass: "", uomClass: "",
      cls: "recon-row-parent"
    });

    let childIdx = 0;
    const nextStruct = () => `${parentInput}.${++childIdx}`;

    // Infor rows
    inforBom.forEach(item => {
      const match = onshapeByPN.get(normPN(item.partNumber));
      const inOnshape = !!match;
      const qtyChanged = inOnshape && qtyDiffers(item.quantity, match.quantity);
      const uomChanged = inOnshape && (normUom(item.uom) !== normUom(match.uom));
      const isUpdate = inOnshape && (qtyChanged || uomChanged);

      // Determine row kind:
      //   not in Onshape           -> DELETE
      //   in Onshape, qty/uom diff -> UPDATE
      //   in Onshape, all same     -> REFERENCE (blank action/type)
      let rowKind, action, type, cls;
      if (!inOnshape) {
        rowKind = "DELETE"; action = "DELETE"; type = "CURRENT MATERIAL"; cls = "recon-row-delete";
      } else if (isUpdate) {
        rowKind = "UPDATE"; action = "UPDATE"; type = "CURRENT MATERIAL"; cls = "";
      } else {
        rowKind = "REFERENCE"; action = ""; type = ""; cls = "";
      }

      reconRows.push({
        action, type, rowKind,
        bomStruct: nextStruct(),
        partNumber: item.partNumber,
        description: item.partName,
        quantity: fmtQty(item.quantity),   // keep Infor quantity in the main column
        uom: item.uom,                      // keep Infor UoM in the main column
        mass: "",                           // mass only shown on ADD rows
        seq: item.seq || "",
        // ADD/DELETE/UPDATE rows carry the parent assembly PN + operation.
        showParentPN: !inOnshape || isUpdate,
        // UPDATE rows: new Onshape values (both always populated) + which differ.
        newQty: isUpdate ? fmtQty(match.quantity) : "",
        newUom: isUpdate ? normUomDisplay(match.uom) : "",
        qtyChanged, uomChanged,
        qtyClass: "", uomClass: "",
        cls
      });
    });

    // New Onshape rows (ADD) — no seq (Onshape has none)
    onshapeBom.forEach(item => {
      if (!inforByPN.has(normPN(item.partNumber))) {
        reconRows.push({
          action: "ADD", type: "CURRENT MATERIAL",
          rowKind: "ADD",
          bomStruct: nextStruct(),
          partNumber: item.partNumber,
          description: item.partName,
          quantity: fmtQty(item.quantity),
          uom: normUomDisplay(item.uom),   // shortened UoM (EACH -> EA)
          mass: fmtMass(item.mass),
          seq: "",
          showParentPN: true,   // ADD rows carry the parent assembly PN
          qtyClass: "", uomClass: "",
          cls: "recon-row-add"
        });
      }
    });

    return reconRows;
  }

  const tagClass = (kind) =>
    kind === "ADD" ? "tag tag-add" :
    kind === "DELETE" ? "tag tag-delete" :
    kind === "UPDATE" ? "tag tag-update" : "tag tag-ref";

  // Parent assembly PN (shown in the "Parent Assembly" trailing column).
  const parentAssemblyPN = (infor && infor.assembly) || (onshape && onshape.assembly) || "";

  // Per-row override state. Key = bomStruct (stable within a given parent input).
  // When a row is ignored, ADD/DELETE/UPDATE rows revert to a plain reference.
  const overrides = new Set();

  // Trailing columns after the 8 main columns (indices 0-12):
  //   0-4  : blank
  //   5    : Parent Assembly PN (change rows; blanked when ignored)
  //   6    : blank
  //   7    : New Qty  (UPDATE rows only — 2 cols after Parent Assembly)
  //   8    : New UoM  (UPDATE rows only — directly after New Qty)
  //   9    : Operation ("10" for non-ignored change rows)
  //   10-11: blank
  //   12   : Seq (from Infor; blank for ADD and the parent row)
  function trailingCols(row) {
    const ignored = isIgnored(row);
    const isChange = (row.rowKind === "ADD" || row.rowKind === "DELETE" || row.rowKind === "UPDATE") && !ignored;
    const pn = (row.showParentPN && !ignored) ? parentAssemblyPN : "";
    const operation = isChange ? "10" : "";
    // New Qty / New UoM only on non-ignored UPDATE rows.
    const isUpdate = row.rowKind === "UPDATE" && !ignored;
    const newQty = isUpdate ? (row.newQty || "") : "";
    const newUom = isUpdate ? (row.newUom || "") : "";
    return ["", "", "", "", "", pn, "", newQty, newUom, operation, "", "", (row.seq || "")];
  }

  const TRAILING_HEADERS = ["", "", "", "", "", "Parent Assembly", "", "New Qty", "New UoM", "Operation", "", "", "Seq"];

  // Is this row currently ignored (checkbox ticked)?
  function isIgnored(row) {
    const canIgnore = row.rowKind === "ADD" || row.rowKind === "DELETE" || row.rowKind === "UPDATE";
    return canIgnore && overrides.has(row.bomStruct);
  }

  // Effective action/type for a row given its ignored state.
  // Ignored DELETE and UPDATE rows get blanked action & type (row still shown/
  // copied as a plain reference). Ignored ADD rows are dropped from copy entirely.
  function effActionType(row) {
    if (isIgnored(row) && (row.rowKind === "DELETE" || row.rowKind === "UPDATE")) {
      return { action: "", type: "" };
    }
    return { action: row.action, type: row.type };
  }

  function renderReconInto(elId, reconRows) {
    const body = reconRows.map(row => {
      const ignored = isIgnored(row);
      const { action, type } = effActionType(row);
      // For non-ignored UPDATE rows, highlight the cells that actually changed:
      // original + New Qty (if qty changed), original + New UoM (if uom changed).
      const activeUpdate = row.rowKind === "UPDATE" && !ignored;
      const hlQty = activeUpdate && row.qtyChanged;
      const hlUom = activeUpdate && row.uomChanged;

      const trailVals = trailingCols(row);
      const trail = trailVals.map((v, i) => {
        let cls = "";
        if (hlQty && i === 7) cls = ' class="cell-orange"';       // New Qty (blue)
        if (hlUom && i === 8) cls = ' class="cell-brightyellow"'; // New UoM (bright yellow)
        return `<td${cls}>${esc(v)}</td>`;
      }).join("");

      // UPDATE tag is plain text (no colored box); ADD/DELETE keep their tags.
      const actionCell = action
        ? (row.rowKind === "UPDATE"
            ? esc(action)
            : `<span class="${tagClass(row.rowKind)}">${esc(action)}</span>`)
        : "";

      // Checkbox on ADD/DELETE/UPDATE rows.
      const canIgnoreRow = row.rowKind === "ADD" || row.rowKind === "DELETE" || row.rowKind === "UPDATE";
      const checkbox = canIgnoreRow
        ? `<input type="checkbox" class="override-cb" data-struct="${esc(row.bomStruct)}" ${ignored ? "checked" : ""} title="Ignore this row">`
        : "";

      // Visual treatment when ignored:
      //   DELETE / UPDATE -> light gray row (action/type blanked, still copied)
      //   ADD             -> grayed + strikethrough (excluded from all copies)
      let rowClass = row.cls;
      if (ignored && (row.rowKind === "DELETE" || row.rowKind === "UPDATE")) rowClass = "recon-row-ignored-delete";
      if (ignored && row.rowKind === "ADD")    rowClass = "recon-row-ignored-add";

      const mainQtyClass = "num" + (hlQty ? " cell-orange" : (row.qtyClass ? " " + row.qtyClass : ""));
      const mainUomClass = hlUom ? "cell-brightyellow" : (row.uomClass || "");

      return `
      <tr class="${rowClass}">
        <td class="ovr">${checkbox}</td>
        <td>${actionCell}</td>
        <td>${esc(type)}</td>
        <td class="mono">${esc(fmtBomStruct(row.bomStruct))}</td>
        <td>${esc(row.partNumber)}</td>
        <td>${esc(row.description)}</td>
        <td class="${mainQtyClass}">${esc(row.quantity)}</td>
        <td class="${mainUomClass}">${esc(row.uom)}</td>
        <td class="num">${esc(row.mass)}</td>
        ${trail}
      </tr>`;
    }).join("");

    const trailHead = TRAILING_HEADERS.map(h => `<th>${esc(h)}</th>`).join("");

    document.getElementById(elId).innerHTML = `
      <table class="recon-tbl">
        <thead>
          <tr>
            <th class="ovr">Ignore</th>
            <th>Action</th><th>Type</th><th>BOM Structure</th>
            <th>Part Number</th><th>Description</th><th class="num">Quantity</th><th>UoM</th><th class="num">Mass</th>
            ${trailHead}
          </tr>
        </thead>
        <tbody>${body}</tbody>
      </table>`;

    // Wire override checkboxes
    document.querySelectorAll(`#${elId} .override-cb`).forEach(cb => {
      cb.addEventListener("change", () => {
        const struct = cb.getAttribute("data-struct");
        if (cb.checked) overrides.add(struct);
        else overrides.delete(struct);
        renderReconInto(elId, reconRows); // re-render to reflect the change
      });
    });
  }

  // Build a TSV string for clipboard (Excel-ready). Header row is EXCLUDED per
  // request. Rules:
  //   - Ignored ADD rows are excluded from ALL copies.
  //   - Ignored DELETE/UPDATE rows still copy, but with blanked action & type
  //     (and blanked parent/new-qty/new-uom via trailingCols); they stay gray.
  //   - `onlyChanges` keeps rows with a nonblank action AND type (includes the
  //     parent REFERENCE/ITEM row for context). Ignored delete/update rows have
  //     blanked action/type so they drop out of the changes-only copy.
  // Uses fmtBomStruct so trailing-zero structures survive paste.
  function reconToTSV(reconRows, onlyChanges) {
    const rows = reconRows
      // Drop ignored ADD rows entirely.
      .filter(r => !(isIgnored(r) && r.rowKind === "ADD"))
      .map(r => {
        const { action, type } = effActionType(r);
        return { ...r, action, type };
      })
      .filter(r => onlyChanges ? (r.action && r.type) : true);
    const lines = rows.map(row => [
      row.action, row.type, fmtBomStruct(row.bomStruct),
      row.partNumber, row.description, row.quantity, row.uom, row.mass,
      ...trailingCols(row)
    ].join("\t"));
    return lines.join("\n");
  }

  function buildRecon() {
    if (!inforBom.length || !onshapeBom.length) return;
    const parentInput = document.getElementById("parent-bom").value.trim() || "1";
    const reconRows = computeReconRows(parentInput);

    renderReconInto("recon-table", reconRows);

    const wireCopy = (btnId, label, onlyChanges) => {
      const btn = document.getElementById(btnId);
      if (!btn) return;
      btn.onclick = () => {
        navigator.clipboard.writeText(reconToTSV(reconRows, onlyChanges)).then(() => {
          btn.textContent = "Copied!";
          setTimeout(() => btn.textContent = label, 1500);
        });
      };
    };
    wireCopy("copy-full", "Copy full table", false);
    wireCopy("copy-changes", "Copy changes only", true);
  }

  // ─── Infor items section ────────────────────────────────────────────────────
  // A standalone table of just the Infor BOM in the ECO-template column layout,
  // independent of the ECO template. No Ignore column, no highlighting, blank
  // action/type on all rows except the parent (which keeps REFERENCE/ITEM).
  // Parent Assembly and Operation are filled on every child row; mass blank.

  // Trailing columns for the Infor-items table (indices 0-12):
  //   5 = Parent Assembly, 9 = Operation, 12 = Seq (all others blank).
  function inforTrailingCols(row) {
    return ["", "", "", "", "", (row.parentAsm || ""), "", "", "",
            (row.operation || ""), "", "", (row.seq || "")];
  }

  function computeInforRows(parentInput) {
    const rows = [];
    // Parent row — REFERENCE/ITEM, description + shortened UoM, no parent/op/seq.
    rows.push({
      action: "REFERENCE", type: "ITEM",
      bomStruct: parentInput,
      partNumber: (infor && infor.assembly) || "",
      description: (onshape && onshape.assemblyDesc) || "",
      quantity: "",
      uom: normUomDisplay((onshape && onshape.assemblyUom) || ""),
      mass: "",
      parentAsm: "",
      operation: "",
      seq: "",
      cls: "recon-row-parent"
    });

    let idx = 0;
    const nextStruct = () => `${parentInput}.${++idx}`;

    inforBom.forEach(item => {
      rows.push({
        action: "",           // blank on all non-parent rows
        type: "",
        bomStruct: nextStruct(),
        partNumber: item.partNumber,
        description: item.partName,
        quantity: fmtQty(item.quantity),
        uom: normUomDisplay(item.uom),   // shortened
        mass: "",                         // always blank
        parentAsm: parentAssemblyPN,      // filled on every child row
        operation: "10",                  // filled on every child row
        seq: item.seq || "",
        cls: ""
      });
    });

    return rows;
  }

  function renderInforInto(elId, rows) {
    const body = rows.map(row => {
      const trail = inforTrailingCols(row).map(v => `<td>${esc(v)}</td>`).join("");
      const actionCell = row.action
        ? `<span class="tag tag-ref">${esc(row.action)}</span>`
        : "";
      return `
      <tr class="${row.cls}">
        <td>${actionCell}</td>
        <td>${esc(row.type)}</td>
        <td class="mono">${esc(fmtBomStruct(row.bomStruct))}</td>
        <td>${esc(row.partNumber)}</td>
        <td>${esc(row.description)}</td>
        <td class="num">${esc(row.quantity)}</td>
        <td>${esc(row.uom)}</td>
        <td class="num">${esc(row.mass)}</td>
        ${trail}
      </tr>`;
    }).join("");

    const trailHead = TRAILING_HEADERS.map(h => `<th>${esc(h)}</th>`).join("");

    document.getElementById(elId).innerHTML = `
      <table class="recon-tbl infor-items-tbl">
        <thead>
          <tr>
            <th>Action</th><th>Type</th><th>BOM Structure</th>
            <th>Part Number</th><th>Description</th><th class="num">Quantity</th><th>UoM</th><th class="num">Mass</th>
            ${trailHead}
          </tr>
        </thead>
        <tbody>${body}</tbody>
      </table>`;
  }

  function inforToTSV(rows) {
    // Header excluded, like the ECO template copy.
    return rows.map(row => [
      row.action, row.type, fmtBomStruct(row.bomStruct),
      row.partNumber, row.description, row.quantity, row.uom, row.mass,
      ...inforTrailingCols(row)
    ].join("\t")).join("\n");
  }

  function buildInforItems() {
    if (!inforBom.length) return;
    const parentInput = (document.getElementById("infor-parent-bom").value || "").trim() || "1";
    const rows = computeInforRows(parentInput);
    renderInforInto("infor-items-table", rows);

    const btn = document.getElementById("copy-infor-items");
    if (btn) {
      btn.onclick = () => {
        navigator.clipboard.writeText(inforToTSV(rows)).then(() => {
          btn.textContent = "Copied!";
          setTimeout(() => btn.textContent = "Copy full table", 1500);
        });
      };
    }
  }

  buildRecon();
  const parentInputEl = document.getElementById("parent-bom");
  if (parentInputEl) parentInputEl.addEventListener("input", buildRecon);

  buildInforItems();
  const inforParentEl = document.getElementById("infor-parent-bom");
  if (inforParentEl) inforParentEl.addEventListener("input", buildInforItems);
});
