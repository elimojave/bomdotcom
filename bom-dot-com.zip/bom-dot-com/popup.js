function fmt(slot) {
  if (!slot || !slot.bom || !slot.bom.length) return null;
  return `${slot.assembly} — ${slot.bom.length} items (${slot.at})`;
}

function render() {
  chrome.storage.session.get(
    ["inforSeen", "inforStored", "onshapeSeen", "onshapeStored"],
    (r) => {
      const set = (id, txt, emptyTxt, baseClass) => {
        const el = document.getElementById(id);
        if (txt) { el.textContent = txt; el.className = baseClass; }
        else { el.textContent = emptyTxt; el.className = "none"; }
      };
      set("infor-seen",    fmt(r.inforSeen),    "nothing seen yet", "seen-infor");
      set("infor-stored",  fmt(r.inforStored),  "nothing stored",   "stored-infor");
      set("onshape-seen",  fmt(r.onshapeSeen),  "nothing seen yet", "seen-onshape");
      set("onshape-stored",fmt(r.onshapeStored),"nothing stored",   "stored-onshape");

      // Highlight summary button yellow when both stored assembly PNs match
      const btn = document.getElementById("summary-btn");
      const line = document.getElementById("match-line");
      const ip = r.inforStored && r.inforStored.assembly;
      const op = r.onshapeStored && r.onshapeStored.assembly;
      const norm = s => (s || "").trim().toUpperCase();
      if (ip && op && norm(ip) === norm(op)) {
        btn.classList.add("match");
        line.textContent = "assemblies match: " + ip;
        line.className = "yes";
      } else {
        btn.classList.remove("match");
        line.textContent = (ip && op) ? "assemblies differ" : "";
        line.className = "no";
      }
    }
  );
}

function setErr(id, msg) {
  document.getElementById(id).textContent = msg || "";
}

render();
// Refresh the "seen" lines live while the popup is open
const poll = setInterval(render, 1000);
window.addEventListener("unload", () => clearInterval(poll));

// ─── Load (commit seen -> stored) ───────────────────────────────────────────
document.getElementById("infor-btn").addEventListener("click", () => {
  setErr("infor-err", "");
  chrome.runtime.sendMessage({ type: "COMMIT_INFOR" }, (resp) => {
    if (!resp || !resp.ok) setErr("infor-err", resp ? resp.error : "failed");
    render();
  });
});

document.getElementById("onshape-btn").addEventListener("click", () => {
  setErr("onshape-err", "");
  chrome.runtime.sendMessage({ type: "COMMIT_ONSHAPE" }, (resp) => {
    if (!resp || !resp.ok) setErr("onshape-err", resp ? resp.error : "failed");
    render();
  });
});

// ─── View Summary ───────────────────────────────────────────────────────────
document.getElementById("summary-btn").addEventListener("click", () => {
  chrome.tabs.create({ url: chrome.runtime.getURL("summary.html") });
});
