// ISOLATED world: parse Onshape BOM response posted by injected_onshape.js.
// Resolves columns by their header propertyName (robust against ID changes),
// falling back to known IDs only if names are missing.
const LOG = "[BOMCapture/onshape-content]";
console.log(LOG, "loaded:", location.href);

// Known fallback IDs (from observed response). partName/partNumber/mass confirmed.
const FALLBACK_IDS = {
  partName:   "57f3fb8efa3416c06701d60d",
  partNumber: "57f3fb8efa3416c06701d60f",
  quantity:   "5ace84d3c046ad611c65a0dd",
  uom:        "57f3fb8efa3416c06701d623",
  mass:       "57f3fb8efa3416c06701d626",
};

// Map a header propertyName (lowercased) to our field keys.
function classifyHeader(name) {
  const n = (name || "").toLowerCase();
  if (n === "quantity") return "quantity";
  if (n === "name") return "partName";
  if (n === "part number" || n === "partnumber") return "partNumber";
  if (n === "unit of measure" || n === "uom" || n === "units") return "uom";
  if (n === "mass") return "mass";
  return null;
}

function buildColumnMap(headers) {
  // Returns { fieldKey: headerId }
  const map = {};
  (headers || []).forEach(h => {
    const key = classifyHeader(h.propertyName);
    if (key && h.id && !map[key]) map[key] = h.id;
  });
  return map;
}

window.addEventListener("message", (event) => {
  if (event.source !== window) return;
  const msg = event.data;
  if (!msg || msg.__bomCapture !== true || msg.site !== "onshape") return;

  const data = msg.data;
  const rows = data.rows || [];
  const colMap = buildColumnMap(data.headers);

  console.log(LOG, "resolved columns:", JSON.stringify(colMap));

  // Resolve a field: prefer the confirmed known ID; only use the header-name
  // mapping for fields we don't have a known ID for.
  const getVal = (v, key) => {
    const id = FALLBACK_IDS[key] || colMap[key];
    return id && v[id] != null ? v[id] : "";
  };

  // The parent assembly PN is the part-number field of the top-level assembly
  // row (response was requested with includeTopLevelAssemblyRow=true). Fall back
  // to bomSource.name only if that row/field is missing.
  let assemblyName = "";
  let assemblyDesc = "";
  let assemblyUom = "";
  const topRow = data.topLevelAssemblyRow;
  if (topRow && topRow.headerIdToValue) {
    assemblyName = getVal(topRow.headerIdToValue, "partNumber");
    assemblyDesc = getVal(topRow.headerIdToValue, "partName");
    assemblyUom  = getVal(topRow.headerIdToValue, "uom");
  }
  if (!assemblyName) {
    assemblyName = data.bomSource?.name || data.name || "Unknown Assembly";
  }

  const bom = rows
    .filter(row => row.headerIdToValue)
    // Only include top-level rows; exclude sub-assembly children (indentLevel > 0)
    .filter(row => (row.indentLevel || 0) === 0)
    .map(row => {
      const v = row.headerIdToValue;
      return {
        partNumber: getVal(v, "partNumber"),
        partName:   getVal(v, "partName"),
        quantity:   getVal(v, "quantity"),
        uom:        getVal(v, "uom"),
        mass:       getVal(v, "mass"),
      };
    })
    .filter(row => row.partNumber);

  if (!bom.length) return;

  console.log(LOG, `seen ${bom.length} items for ${assemblyName}`,
              "sample:", JSON.stringify(bom[0]));
  chrome.runtime.sendMessage({
    type: "ONSHAPE_BOM_SEEN",
    bom,
    assemblyName,
    assemblyDesc,
    assemblyUom
  });
});
