// ISOLATED world: parse Infor BOM rows posted by injected_infor.js,
// store as the "seen" (live) slot — NOT committed until user clicks Load.
const LOG = "[BOMCapture/infor-content]";
console.log(LOG, "loaded:", location.href);

// Default column indices in the GenerateServerEvent response row array.
// These can be overridden by the user via the Settings tab (stored in
// chrome.storage.local under "inforColMap"). Infor occasionally shifts these
// when the form changes, so they're adjustable without a code update.
const DEFAULT_COL = {
  assembly:     6,
  material:     9,
  materialDesc: 10,
  quantity:     11,
  uom:          12,
  seq:          14,
};

// Load any saved overrides, then merge with defaults.
function getColMap(cb) {
  try {
    chrome.storage.local.get("inforColMap", (res) => {
      const saved = (res && res.inforColMap) || {};
      cb({ ...DEFAULT_COL, ...saved });
    });
  } catch (e) {
    cb({ ...DEFAULT_COL });
  }
}

window.addEventListener("message", (event) => {
  if (event.source !== window) return;
  const msg = event.data;
  if (!msg || msg.__bomCapture !== true || msg.site !== "infor") return;

  const rows = msg.rows || [];
  if (!rows.length) return;

  getColMap((COL) => {
    const bom = rows.map(row => ({
      partNumber: (row[COL.material]     || "").trim(),
      partName:   (row[COL.materialDesc] || "").trim(),
      quantity:   (row[COL.quantity]     || "").trim(),
      uom:        (row[COL.uom]          || "").trim(),
      seq:        (row[COL.seq]          || "").trim(),
    })).filter(r => r.partNumber);

    if (!bom.length) return;

    const assemblyName = (rows[0][COL.assembly] || "").trim();

    // Stash ONE representative raw row so the Settings tab can display it as a
    // numbered list for easy re-mapping (no DevTools needed).
    const sampleRow = rows[0];

    console.log(LOG, `seen ${bom.length} items for ${assemblyName}`);
    chrome.runtime.sendMessage({
      type: "INFOR_BOM_SEEN",
      bom,
      assemblyName,
      sampleRow
    });
  });
});
