// Runs in Onshape's MAIN world — passively observes BOM responses.
(function () {
  const TARGET = "/bom?";          // matches the assemblies .../bom?indented=...
  const LOG = "[BOMCapture/onshape-injected]";
  console.log(LOG, "loaded:", location.href);

  function handleResponseText(text, source) {
    if (!text) return;
    let data;
    try { data = JSON.parse(text); } catch (e) { return; }
    if (!data || !Array.isArray(data.rows)) return;
    // Hand the raw response to the content script for parsing
    window.postMessage({ __bomCapture: true, site: "onshape", data: data }, "*");
    console.log(LOG, `${source}: observed BOM (${data.rows.length} rows)`);
  }

  // ─── Hook XMLHttpRequest ────────────────────────────────────────────────────
  const origOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this.__bomUrl = url;
    return origOpen.call(this, method, url, ...rest);
  };
  const origSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.send = function (...args) {
    if (this.__bomUrl && String(this.__bomUrl).includes(TARGET)) {
      this.addEventListener("load", () => {
        const rt = this.responseType;
        try {
          if (rt === "" || rt === "text") handleResponseText(this.responseText, "xhr/text");
          else if (rt === "json") handleResponseText(JSON.stringify(this.response), "xhr/json");
          else if (rt === "arraybuffer") handleResponseText(new TextDecoder("utf-8").decode(this.response), "xhr/arraybuffer");
        } catch (e) { /* ignore */ }
      });
    }
    return origSend.apply(this, args);
  };

  // ─── Hook fetch (Onshape's client likely uses fetch) ────────────────────────
  const origFetch = window.fetch;
  window.fetch = function (input, init) {
    const url = typeof input === "string" ? input : (input && input.url) || "";
    const promise = origFetch.call(this, input, init);
    if (url.includes(TARGET)) {
      promise.then(resp => {
        resp.clone().text().then(t => handleResponseText(t, "fetch")).catch(() => {});
      }).catch(() => {});
    }
    return promise;
  };

  console.log(LOG, "hooks installed");
})();
