(function () {
  const TARGET = "AppApi/GenerateServerEvent";
  const LOG = "[BOMCapture/injected]";
  console.log(LOG, "loaded in frame:", location.href);

  function handleResponseText(responseText, source) {
    if (!responseText) { console.log(LOG, `${source}: empty`); return; }
    let data;
    try { data = JSON.parse(responseText); }
    catch (e) { console.log(LOG, `${source}: not JSON`); return; }
    const payload = data && data.Payload;
    if (!Array.isArray(payload)) { console.log(LOG, `${source}: no array Payload`); return; }
    for (const action of payload) {
      if (action && typeof action === "object" &&
          action.action === "setcol" && action.target === "PR" &&
          Array.isArray(action.payload) && action.payload.length > 0) {
        console.log(LOG, `${source}: FOUND BOM, ${action.payload.length} rows`);
        window.postMessage({ __bomCapture: true, site: "infor", rows: action.payload }, "*");
        return;
      }
    }
    console.log(LOG, `${source}: actions present:`, payload.map(a => a && a.action).join(", "));
  }

  function extractFromXhr(xhr) {
    const rt = xhr.responseType;
    try {
      if (rt === "" || rt === "text") handleResponseText(xhr.responseText, "xhr/text");
      else if (rt === "json") handleResponseText(JSON.stringify(xhr.response), "xhr/json");
      else if (rt === "arraybuffer") handleResponseText(new TextDecoder("utf-8").decode(xhr.response), "xhr/arraybuffer");
      else console.log(LOG, "xhr: unhandled responseType:", rt);
    } catch (e) { console.log(LOG, "xhr extract error:", e.message); }
  }

  const origOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this.__bomUrl = url;
    return origOpen.call(this, method, url, ...rest);
  };

  const origSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.send = function (...args) {
    if (this.__bomUrl && String(this.__bomUrl).includes(TARGET)) {
      console.log(LOG, "observing GenerateServerEvent (xhr)");
      this.addEventListener("load", () => extractFromXhr(this));
    }
    return origSend.apply(this, args);
  };

  const origFetch = window.fetch;
  window.fetch = function (input, init) {
    const url = typeof input === "string" ? input : (input && input.url) || "";
    const promise = origFetch.call(this, input, init);
    if (url.includes(TARGET)) {
      console.log(LOG, "observing GenerateServerEvent (fetch)");
      promise.then(resp => {
        resp.clone().text().then(t => handleResponseText(t, "fetch")).catch(() => {});
      }).catch(() => {});
    }
    return promise;
  };

  console.log(LOG, "hooks installed");
})();
