// Stores two kinds of slots per site:
//   *Seen*   — latest BOM passively observed (live, auto-updates)
//   *Stored* — committed snapshot (only when user clicks Load)
// Commit (seen -> stored) is handled in the popup via COMMIT messages.

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const now = new Date().toLocaleString();

  // ─── Passive "seen" updates ───────────────────────────────────────────────
  if (message.type === "INFOR_BOM_SEEN") {
    chrome.storage.session.set({
      inforSeen: {
        bom: message.bom,
        assembly: message.assemblyName,
        at: now
      },
      // Keep the latest representative raw row for the Settings inspector.
      inforSampleRow: message.sampleRow || null
    });
  }
  if (message.type === "ONSHAPE_BOM_SEEN") {
    chrome.storage.session.set({
      onshapeSeen: {
        bom: message.bom,
        assembly: message.assemblyName,
        assemblyDesc: message.assemblyDesc || "",
        assemblyUom: message.assemblyUom || "",
        at: now
      }
    });
  }

  // ─── Commit "seen -> stored" (triggered by Load buttons) ──────────────────
  if (message.type === "COMMIT_INFOR") {
    chrome.storage.session.get("inforSeen", (r) => {
      if (r.inforSeen) {
        chrome.storage.session.set({ inforStored: r.inforSeen });
        sendResponse({ ok: true, ...r.inforSeen });
      } else {
        sendResponse({ ok: false, error: "Nothing seen yet — search an assembly in SyteLine." });
      }
    });
    return true; // async
  }
  if (message.type === "COMMIT_ONSHAPE") {
    chrome.storage.session.get("onshapeSeen", (r) => {
      if (r.onshapeSeen) {
        chrome.storage.session.set({ onshapeStored: r.onshapeSeen });
        sendResponse({ ok: true, ...r.onshapeSeen });
      } else {
        sendResponse({ ok: false, error: "Nothing seen yet — open the BOM tool in Onshape." });
      }
    });
    return true; // async
  }
});
